TRUNCATE `kb3_races`;
INSERT IGNORE INTO `kb3_races` VALUES(1, 'Caldari'), (2, 'Minmatar'), (4, 'Amarr'), (8, 'Gallente'), (16, 'Jove'), (32, 'Pirate'), (64, 'Sleepers'), (128, 'ORE');
