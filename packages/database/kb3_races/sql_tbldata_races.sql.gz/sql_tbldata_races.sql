TRUNCATE `kb3_races`;
INSERT IGNORE INTO `kb3_races` VALUES('1', 'Caldari');
INSERT IGNORE INTO `kb3_races` VALUES('2', 'Minmatar');
INSERT IGNORE INTO `kb3_races` VALUES('4', 'Amarr');
INSERT IGNORE INTO `kb3_races` VALUES('8', 'Gallente');
INSERT IGNORE INTO `kb3_races` VALUES('16', 'Jove');
INSERT IGNORE INTO `kb3_races` VALUES('32', 'Pirate');
