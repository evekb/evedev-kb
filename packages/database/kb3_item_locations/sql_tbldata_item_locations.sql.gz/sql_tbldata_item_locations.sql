TRUNCATE `kb3_item_locations`;
INSERT INTO `kb3_item_locations` (`itl_id`, `itl_location`) VALUES (4, 'Cargo'), (9, 'Copy'), (6, 'Drone Bay'), (1, 'Fitted - High slot'), (3, 'Fitted - Low slot'), (2, 'Fitted - Medium slot'), (8, 'Implant'), (5, 'Rig Slot'), (7, 'Subsystem Slot');
