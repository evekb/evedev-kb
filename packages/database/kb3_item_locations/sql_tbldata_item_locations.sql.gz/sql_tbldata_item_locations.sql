TRUNCATE `kb3_item_locations`;
INSERT IGNORE INTO `kb3_item_locations` VALUES('1', 'Fitted - High slot'), ('2', 'Fitted - Medium slot'), ('3', 'Fitted - Low slot'), ('4', 'Cargo'), ('5', 'Rig Slot'), ('6', 'Drone Bay'), ('7', 'Subsystem Slot');
