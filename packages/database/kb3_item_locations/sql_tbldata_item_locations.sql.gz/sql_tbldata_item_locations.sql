TRUNCATE `kb3_item_locations`;
INSERT IGNORE INTO `kb3_item_locations` VALUES('1', 'Fitted - High slot');
INSERT IGNORE INTO `kb3_item_locations` VALUES('2', 'Fitted - Medium slot');
INSERT IGNORE INTO `kb3_item_locations` VALUES('3', 'Fitted - Low slot');
INSERT IGNORE INTO `kb3_item_locations` VALUES('4', 'Cargo');
INSERT IGNORE INTO `kb3_item_locations` VALUES('5', 'Rig Slot');
INSERT IGNORE INTO `kb3_item_locations` VALUES('6', 'Drone Bay');
INSERT IGNORE INTO `kb3_item_locations` VALUES('7', 'Subsystem Slot');
